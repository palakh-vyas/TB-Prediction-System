import joblib
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="TB Risk Screening", page_icon="🫁")


@st.cache_resource
def load_files():
    model = joblib.load("models/tb_model.pkl")
    symptoms = joblib.load("models/symptom_list.pkl")
    scaler = joblib.load("models/scaler.pkl")
    genders = joblib.load("models/gender_columns.pkl")
    return model, symptoms, scaler, genders


model, symptom_list, scaler, gender_columns = load_files()

st.title("🫁 Tuberculosis Risk Screening System")
tab1, tab2, tab3 = st.tabs(["Prediction", "Model Performance", "About"])

with tab1:
    st.write("Fill in the patient details and click **Predict**.")

    col1, col2 = st.columns(2)
    age = col1.number_input("Age", min_value=1, max_value=100, value=30)
    gender = col2.selectbox("Gender", gender_columns)

    chosen = st.multiselect(
        "Select symptoms",
        options=[s.title() for s in symptom_list],
    )

    if st.button("Predict", type="primary"):
        if not chosen:
            st.warning("Please select at least one symptom.")
        else:
            chosen_lower = [c.lower() for c in chosen]
            row = [1 if s in chosen_lower else 0 for s in symptom_list]
            age_scaled = scaler.transform(pd.DataFrame({"Age": [age]}))[0].tolist()
            gender_row = [1 if g == gender else 0 for g in gender_columns]
            x = np.array([row + age_scaled + gender_row])

            risk = model.predict_proba(x)[0][1] * 100

            st.metric("Estimated TB risk score", f"{risk:.1f}%")
            st.progress(min(int(risk), 100))

            if risk >= 70:
                st.error("HIGH risk band - please consult a doctor.")
            elif risk >= 40:
                st.warning("MEDIUM risk band - a check-up is recommended.")
            else:
                st.success("LOW risk band.")

    st.caption("⚠️ This is a screening aid for learning purposes, "
               "not a medical diagnosis. Always consult a doctor.")

with tab2:
    st.subheader("Model comparison")
    try:
        table = pd.read_csv("models/model_comparison.csv", index_col=0)
        st.dataframe(table)
        st.bar_chart(table[["Precision", "Recall", "F1"]])
        st.write("**Recall** = out of all real TB patients, how many the "
                 "model caught. It is the most important score for screening.")
    except FileNotFoundError:
        st.info("Run the training notebook first to create the comparison table.")

with tab3:
    st.subheader("About this project")
    st.write("""
    - **Goal:** estimate TB risk from symptoms, age and gender.
    - **Models compared:** Logistic Regression, Decision Tree, Random Forest.
    - **Imbalance handling:** class weights and stratified split.
    - **Limitation:** the training dataset is synthetic, so results
      demonstrate the pipeline and are not clinically valid.
    """)
